using System.Net.Mail;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace SendNotificationFunApp
{
    public class SendNotificationEmail
    {
        private readonly ILogger<SendNotificationEmail> _logger;

        public SendNotificationEmail(ILogger<SendNotificationEmail> logger)
        {
            _logger = logger;
        }

        //[Function("Function1")]
        //public IActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req)
        //{
        //    _logger.LogInformation("C# HTTP trigger function processed a request.");
        //    return new OkObjectResult("Welcome to Azure Functions!");
        //}

        [Function("SendContactEmail")]
        public static async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var data = JsonConvert.DeserializeObject<ContactModel>(requestBody);

            if (data == null || string.IsNullOrEmpty(data.Email))
            {
                return new BadRequestObjectResult("Invalid contact data.");
            }

            // Send email using SMTP (Replace with your SMTP server details)
            SmtpClient client = new SmtpClient("smtp.gmail.com");
            client.Port = 587;
            client.Credentials = new System.Net.NetworkCredential("ankushtoraskar77@gmail.com", "lfqp ymep mxwu gawr");
            client.EnableSsl = true;

            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("ankushtoraskar77@gmail.com");
            mailMessage.To.Add(data.Email);
            mailMessage.Subject = "New Contact Created";
            mailMessage.Body = $"Hello {data.Name}, thank you for contacting us. Welcome to ProfileWebApp. We will get back to you shortly."; ;
            client.Send(mailMessage);

            return new OkObjectResult(new
            {
                status = "success",
                message = "Email sent successfully."
            });
        }

        public class ContactModel
        {
            public string Name { get; set; }
            public string Email { get; set; }
        }
    }
}
